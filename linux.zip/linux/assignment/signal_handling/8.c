/*8.   Write a Program  parent has to get the data from user and store the data in file.after that 
    	    parent process will  send one signal to child process.child process after receving the 
  	     signal,open the file and convert data to oppsite case and store again in same file.
		Hint : Use pause() in child process.
		           Use signal num 10(usersignal) in parent.*/
