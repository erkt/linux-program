/*7. Write a program to create 3 child process from common parent use random delay between  1 to 10 sec in each child. Use alarm() in parent in such a manner that 
	          Child1 should not exceeds more than 4 sec. 
	          Child2 should not exceeds more than 6 sec.
	          Child3 should not exceeds more than 8 sec.
*/
