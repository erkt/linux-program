#include"header.h"
main()
{
printf("HELOOOOOO..%d.\n",getpid());
while(1);
}

