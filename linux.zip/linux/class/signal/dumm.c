#include"header.h"
main()
{
printf("jshdfh\n");
//sleep(10);
printf("dfgdhsdgdgd\n");
while(1);
}
