#include"header.h"
main()
{
printf("afgbsjf\n");
execl("/bin/ls","ls",NULL);
printf("gahg\n");
}
