#include<stdio.h>
main()
{
printf("Bad boy..\n");
while(1);
}

