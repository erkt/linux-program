///child process
#include"header.h"
main()
{
printf("Helloo..\n");
fork();
fork();
fork();
fork();
printf("Hi...\n");
while(1);
}
