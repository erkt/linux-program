#include"header.h"
main(int argc ,char **argv)
{
	pipe p[2],p1[2];
	if(p[2])
