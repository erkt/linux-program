#include<stdio.h>
main()
{
//if(fork()||fork()||fork()||fork()||fork()||fork())
//if(fork()&&fork()&&fork()&&fork()&&fork()&&fork())

//if(fork()&&fork()||fork()&&fork())

if(fork()||fork()&&fork()||fork())
{
printf("Hello...\n");
}
else
;
}
