#include<stdio.h>
main()
{
printf("Heloo...\n");
fork();
fork();
fork();

printf("hi...\n");
while(1);
}
