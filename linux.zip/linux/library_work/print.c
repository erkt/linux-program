void print(int i)
{
printf("%d\n",i);
}
