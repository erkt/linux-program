int mul(int i,int j)
{
return i*j;
}
