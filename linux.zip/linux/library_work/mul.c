void mul(int i,int j)
{
printf("%d * %d = %d\n",i,j,i*j);
}
