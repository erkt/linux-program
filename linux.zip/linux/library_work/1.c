#include<stdio.h>
main()
{
int j=9908,k=8767;
printf("ABCDEGFHIJKLMNOPQRSTUVWXYZ\n");
print(j);
sum(j,k);
mul(10,30);
}
